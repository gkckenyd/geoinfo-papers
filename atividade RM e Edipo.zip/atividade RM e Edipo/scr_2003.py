import time
import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError

def extrair_metadados_completos(url_principal):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        dados_completos = []
        
        try:
            print(f"Acessando a lista principal: {url_principal}...")
            page.goto(url_principal)
            
            # Aguarda o frame que contém a lista de artigos
            frame_lista = page.frame_locator('frame[name="body"]')
            frame_lista.locator("a x").first.wait_for(timeout=15000)
            
            print("Extraindo os links de todos os artigos...")
            
            # Pega o link absoluto (href) de cada artigo da lista
            links_artigos = frame_lista.locator("a").evaluate_all('''links => {
                const urls = [];
                for (let link of links) {
                    if (link.querySelector('x') && link.href) {
                        urls.push(link.href);
                    }
                }
                return urls;
            }''')
            
            print(f"Total de {len(links_artigos)} artigos encontrados. Iniciando a varredura profunda...\n")
            
            # =================================================================
            # ETAPA 2: Navega em cada artigo para extrair os metadados
            # =================================================================
            for index, url_artigo in enumerate(links_artigos, 1):
                print(f"[{index}/{len(links_artigos)}] Lendo metadados de: {url_artigo}")
                
                try:
                    # Entra na página do artigo específico
                    page.goto(url_artigo, wait_until="domcontentloaded", timeout=30000)
                    
                    # Pausa rápida para carregar frames internos e renderização
                    time.sleep(2) 
                    
                    # Script JS aprimorado para buscar metadados ocultos E visíveis
                    metadados = page.evaluate('''() => {
                        const docs = [document];
                        for (let i = 0; i < window.frames.length; i++) {
                            try { docs.push(window.frames[i].document); } catch(e) {}
                        }

                        // Tenta primeiro pelas tags <meta> (Ocultas no cabeçalho)
                        const getMeta = (names) => {
                            for (let doc of docs) {
                                for (const name of names) {
                                    const tags = doc.querySelectorAll(`meta[name="${name}" i]`);
                                    if (tags.length > 0) {
                                        return Array.from(tags).map(t => t.content).join('; ');
                                    }
                                }
                            }
                            return null;
                        };

                        // Se a tag meta não existir, tenta ler o texto visível na tela (Tabelas/Páginas da URLib)
                        // A URLib geralmente coloca os rótulos em negrito (<b>) ou em células de tabela (<td>)
                        const getVisibleText = (label) => {
                            for (let doc of docs) {
                                // Procura por todos os elementos que contêm texto na página
                                const elements = Array.from(doc.querySelectorAll('td, b, span, div, font'));
                                for (let el of elements) {
                                    // Se o texto do elemento bater com o rótulo que estamos procurando (ex: "Resumo")
                                    if (el.textContent.trim().toLowerCase() === label.toLowerCase() || 
                                        el.textContent.trim().toLowerCase() === label.toLowerCase() + ":") {
                                        
                                        // A informação costuma estar no próximo elemento irmão (nextSibling) 
                                        // ou na próxima célula da tabela (nextElementSibling)
                                        let next = el.nextElementSibling || el.nextSibling;
                                        if (next && next.textContent.trim() !== "") {
                                            return next.textContent.replace(/\\s+/g, ' ').trim();
                                        }
                                        
                                        // Fallback: se estiver na mesma linha separada por algo
                                        const parentText = el.parentElement.textContent.replace(/\\s+/g, ' ').trim();
                                        if (parentText.length > label.length + 2) {
                                            return parentText.substring(label.length + 1).trim();
                                        }
                                    }
                                }
                            }
                            return 'N/A';
                        };

                        // Função mestre de extração (Tenta Metatag -> Tenta Texto Visível -> Retorna N/A)
                        const extractData = (metaNames, visibleLabels) => {
                            let result = getMeta(metaNames);
                            if (result && result.trim() !== "") return result;
                            
                            for (const label of visibleLabels) {
                                result = getVisibleText(label);
                                if (result !== 'N/A') return result;
                            }
                            return 'N/A';
                        };

                        return {
                            'Title': extractData(['citation_title', 'DC.title', 'title'], ['Título', 'Title']),
                            'Abstract': extractData(['citation_abstract', 'DC.description', 'abstract'], ['Resumo', 'Abstract']),
                            'Tertiary Type': extractData(['citation_tertiary_type', 'DC.type', 'tertiarytype', 'tertiary type'], ['Tipo de Referência', 'Tertiary Type']),
                            'Language': extractData(['citation_language', 'DC.language', 'language'], ['Idioma', 'Language']),
                            'Conference Name': extractData(['citation_conference_title', 'DC.source', 'conferencename'], ['Evento', 'Conference', 'Conference Name']),
                            'Author': extractData(['citation_author', 'DC.creator', 'author'], ['Autores', 'Author', 'Autor']),
                            'Affiliation': extractData(['citation_author_institution', 'DC.publisher', 'affiliation'], ['Afiliação', 'Affiliation'])
                        };
                    }''')
                    
                    dados_completos.append(metadados)
                
                except Exception as erro_artigo:
                    print(f"Erro ao acessar {url_artigo}: {erro_artigo}")
                    dados_completos.append({
                        'Title': 'Erro na leitura', 'Abstract': 'N/A', 'Tertiary Type': 'N/A',
                        'Language': 'N/A', 'Conference Name': 'N/A', 'Author': 'N/A', 'Affiliation': 'N/A'
                    })

            return dados_completos

        except TimeoutError:
            print("Erro: A página principal demorou muito para responder.")
            return []
        except Exception as e:
            print(f"Ocorreu um erro inesperado: {e}")
            return []
        finally:
            browser.close()


# Executando o script principal

url_alvo = "http://mtc-m16c.sid.inpe.br/rep/8JMKD3MGP8W/3H5FH2B" 
dados_extraidos = extrair_metadados_completos(url_alvo)

if dados_extraidos:
    df = pd.DataFrame(dados_extraidos)
    nome_arquivo = 'metadados_completos_inpe_2003.csv'
    
    df.to_csv(nome_arquivo, index=False, encoding='utf-8-sig', sep=';')
    
    print(f"\n[SUCESSO] Todos os metadados de {len(df)} artigos foram salvos em '{nome_arquivo}'.")
    
    print("\n" + "="*90)
    print("                           METADADOS EXTRAÍDOS (VISUALIZAÇÃO)")
    print("="*90)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('display.expand_frame_repr', False)
    
    print(df.to_string(index=False))
    print("="*90 + "\n")
else:
    print("\n[FALHA] Nenhum dado foi processado.")