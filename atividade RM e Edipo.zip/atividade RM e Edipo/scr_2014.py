import time
import pandas as pd
from playwright.sync_api import sync_playwright, TimeoutError

def extrair_metadados_completos(url_principal):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        dados_completos = []
        
        try:
            print(f"Acessando a lista principal: {url_principal}...")
            page.goto(url_principal)
            
            # Aguarda o frame que contém a lista de artigos
            frame_lista = page.frame_locator('frame[name="body"]')
            frame_lista.locator("a x").first.wait_for(timeout=15000)
            
            print("Extraindo os links de todos os artigos...")
            
            # Pega o link absoluto (href) de cada artigo da lista
            links_artigos = frame_lista.locator("a").evaluate_all('''links => {
                const urls = [];
                for (let link of links) {
                    // Filtra para pegar apenas os links reais dos artigos (que contém a tag <x>)
                    if (link.querySelector('x') && link.href) {
                        urls.push(link.href);
                    }
                }
                return urls;
            }''')
            
            print(f"Total de {len(links_artigos)} artigos encontrados. Iniciando a varredura profunda...\n")
            
            # =================================================================
            # ETAPA 2: Navega em cada artigo para extrair os metadados
            # =================================================================
            for index, url_artigo in enumerate(links_artigos, 1):
                print(f"[{index}/{len(links_artigos)}] Lendo metadados de: {url_artigo}")
                
                try:
                    # Entra na página do artigo específico
                    page.goto(url_artigo, wait_until="domcontentloaded", timeout=30000)
                    
                    # Pausa rápida para garantir que os frames internos da página do artigo carreguem as tags <meta>
                    time.sleep(1.5) 
                    
                    # Script JS que varre o HTML buscando as tags de metadados
                    metadados = page.evaluate('''() => {
                        // Função para procurar a tag <meta> em um documento específico
                        const getMeta = (names, doc) => {
                            for (const name of names) {
                                // O "i" no final faz a busca ignorar letras maiúsculas ou minúsculas
                                const tags = doc.querySelectorAll(`meta[name="${name}" i]`);
                                if (tags.length > 0) {
                                    // Se houver mais de um autor/afiliação, junta tudo separando com ponto e vírgula
                                    return Array.from(tags).map(t => t.content).join('; ');
                                }
                            }
                            return '';
                        };

                        // O INPE usa framesets. Precisamos procurar na página principal E nos sub-frames
                        const docs = [document];
                        for (let i = 0; i < window.frames.length; i++) {
                            try { docs.push(window.frames[i].document); } catch(e) {}
                        }

                        // Tenta extrair usando os padrões INPE, Highwire (citation_) e Dublin Core (DC.)
                        const extract = (names) => {
                            for (let doc of docs) {
                                const val = getMeta(names, doc);
                                if (val) return val;
                            }
                            return 'N/A'; // Valor padrão se a informação não existir no artigo
                        };

                        return {
                            'Title': extract(['citation_title', 'DC.title', 'title']),
                            'Abstract': extract(['citation_abstract', 'DC.description', 'abstract']),
                            'Tertiary Type': extract(['citation_tertiary_type', 'DC.type', 'tertiarytype', 'tertiary type']),
                            'Language': extract(['citation_language', 'DC.language', 'language']),
                            'Conference Name': extract(['citation_conference_title', 'DC.source', 'conferencename']),
                            'Author': extract(['citation_author', 'DC.creator', 'author']),
                            'Affiliation': extract(['citation_author_institution', 'DC.publisher', 'affiliation'])
                        };
                    }''')
                    
                    dados_completos.append(metadados)
                
                except Exception as erro_artigo:
                    print(f"Erro ao acessar {url_artigo}: {erro_artigo}")
                    # Para o código não quebrar e as colunas ficarem alinhadas no CSV, adicionamos 'N/A' caso o site falhe num link específico
                    dados_completos.append({
                        'Title': 'Erro na leitura', 'Abstract': 'N/A', 'Tertiary Type': 'N/A',
                        'Language': 'N/A', 'Conference Name': 'N/A', 'Author': 'N/A', 'Affiliation': 'N/A'
                    })

            return dados_completos

        except TimeoutError:
            print("Erro: A página principal demorou muito para responder.")
            return []
        except Exception as e:
            print(f"Ocorreu um erro inesperado: {e}")
            return []
        finally:
            browser.close()

# Executando o script principal
url_alvo = "http://mtc-m16c.sid.inpe.br/rep/8JMKD3MGPDW34P/42T2678"
dados_extraidos = extrair_metadados_completos(url_alvo)

if dados_extraidos:
    # Transforma a lista de dicionários num DataFrame configurado com as exatas colunas solicitadas
    df = pd.DataFrame(dados_extraidos)
    nome_arquivo = 'metadados_completos_inpe_2014.csv'
    
    # Exporta para CSV preservando acentos
    df.to_csv(nome_arquivo, index=False, encoding='utf-8-sig', sep=';')
    
    print(f"\n[SUCESSO] Todos os metadados de {len(df)} artigos foram salvos em '{nome_arquivo}'.")
    
    # Configuração para mostrar a tabela completinha no terminal, sem cortar as frases longas
    print("\n" + "="*90)
    print("                           METADADOS EXTRAÍDOS (VISUALIZAÇÃO)")
    print("="*90)
    pd.set_option('display.max_rows', None)
    pd.set_option('display.max_columns', None)
    pd.set_option('display.max_colwidth', None)
    pd.set_option('display.expand_frame_repr', False)
    
    print(df.to_string(index=False))
    print("="*90 + "\n")
else:
    print("\n[FALHA] Nenhum dado foi processado.")